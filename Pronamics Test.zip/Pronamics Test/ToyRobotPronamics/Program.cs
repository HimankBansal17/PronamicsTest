﻿// See https://aka.ms/new-console-template for more information
using ToyRobotPronamics;
Console.WriteLine("Starting Simulation for the toy robot\n");

var simulation = new Setup(10 ,10);
simulation.StartProgram();





