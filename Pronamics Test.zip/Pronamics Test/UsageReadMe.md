# Toy Robot Simulation

The Solution Has 2 Projects One for Unit test and other is a main console app ToyRobotPronamics

# The console app takes inputs in a loop and does not reads from a file
The input Instrucutions are mentioned on console app load.

# Testing
To Test the app you can run the unit tests with different parameters to confirm.